import{a}from"./motion.C2aLgLls.js";requestAnimationFrame(()=>a());
